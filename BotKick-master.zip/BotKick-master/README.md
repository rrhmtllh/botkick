# BotKick
Self Bot Kicker Line
Created by: AntonLow
Line id: @antonlou
